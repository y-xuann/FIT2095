const express = require("express");
const driverCont = require("../controllers/driver-controller");

const router = express.Router();

/**
 * Route to display the page for adding a new driver.
 * @name GET /add-driver
 * @function
 * @description Call the handler method createDriverPage()
 */
router.get("/add-driver", driverCont.createDriverPage);

/**
 * Route to create a new driver.
 * @name POST /add-driver
 * @function
 * @description Call the handler method createDriver()

 */
router.post("/add-driver", driverCont.createDriver);

/**
 * Route to display the list of all drivers.
 * @name GET /
 * @function
 * @description Call the handler method listDriver()
 */
router.get("/", driverCont.listDriver);

/**
 * Route to display the page for filtering drivers by department.
 * @name GET /department
 * @function
 * @description Call the handler method listByDepartmentPage()
 */
router.get("/department", driverCont.listByDepartmentPage);

/**
 * Route to handle filtering drivers by department.
 * @name POST /department
 * @function
 * @description Call the handler method listByDepartment()
 */
router.post("/department", driverCont.listByDepartment);

/**
 * Route to display the page for deleting a driver.
 * @name GET /delete-driver
 * @function
 * @description Call the handler method deleteDriverPage()
 */
router.get("/delete-driver", driverCont.deleteDriverPage);

/**
 * Route to handle driver deletion via query string (e.g., ?id=driverId).
 * @name GET /delete-driver-req
 * @function
 * @description Call the handler method deleteDriver()
 */
router.get("/delete-driver-req", driverCont.deleteDriver);

module.exports = router;
