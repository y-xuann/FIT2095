const db = require("../firebase-config")
let state = require("../models/login-state")

module.exports = { 
    /** 
     * Handler method to display login page
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
    */
	loginPage: function (req, res) {state,
        res.render("user-login.ejs");
	},

    /** 
     * Handler method to handle user login 
     * @async
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
     * @description check if the username and password exist or not 
    */
    loginUser: async function(req,res){
        let invalidUser = true;
        const data = await db.collection('users').get();
        data.forEach((doc) => {
            if (doc.data().username == req.body.username && doc.data().password == req.body.password){
                res.redirect("/");
                invalidUser = false;
                state.loggedIn = true;
        }})
        if (invalidUser){
            res.render("invalid-data.ejs");}
    },

    /** 
     * Handler method to display signup page
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function

    */
    signUpPage: function (req, res) {
        res.render("user-signup.ejs");
	},

    /** 
     * Handler method to handle user signup page
     * @async
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
     * @description perform validation check 
    */
    signUpUser: async function(req,res){
        // validation check
        if (req.body.username.length < 6 || !isAlphaNumeric(req.body.username)){
            res.render("invalid-data.ejs");
        }
        else if(req.body.password.length < 5 || req.body.password.length > 10){
            res.render("invalid-data.ejs");
        }
        else if(req.body.password != req.body.confirm_password){
            res.render("invalid-data.ejs");
        }
        else{
            // the collection name is user
            await db.collection('users')
                .doc() // the key of the document (auto generated for this case)
                .set({'password':req.body.password,
                    'username':req.body.username
            });
            res.redirect("/33520496/Yang/users/login")
        }
    }
}

/**
 * Checks if a string contains only alphanumeric characters (letters and numbers).
 * @function
 * @param {string} str - The string to be tested.
 * @returns {boolean} - Returns `true` if the string contains only alphanumeric characters; `false` otherwise.
 */
function isAlphaNumeric(str){
    return /^[a-z0-9]*$/gi.test(str);
}


