const express = require("express");
const userCont = require("../controllers/user-controller");
const router = express.Router();

/**
 * Route to display login page
 * @name GET /login
 * @function
 * @description Call the handler method loginPage()
 */
router.get("/login", userCont.loginPage);

/**
 * Route to handle user login.
 * @name POST /login
 * @function
 * @description Call the handler method loginUser()
 */
router.post("/login", userCont.loginUser);

/**
 * Route to display signup page
 * @name POST /login
 * @function
 * @description Call the handler method signUpPage()
 */
router.get("/signup", userCont.signUpPage);

/**
 * Route to handle user signup.
 * @name POST /login
 * @function
 * @description Call the handler method signUpUser()
 */
router.post("/signup", userCont.signUpUser);

module.exports = router;