const Driver = require("../models/driver");
const {getCounters, saveData} = require("./counter")
let state = require("../models/login-state")

module.exports = {
    /** 
     * Handler method to display the page to add a new driver
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
    */
	createDriverPage: function (req, res) {
        if(state.loggedIn == true){
            res.render("add-driver.ejs"); // Render the add driver page if logged in
        }else{
            res.redirect("/33520496/Yang/users/login"); // Redirect to login page if not logged in
        }
	},

    /**
     * Handler method which creates a new driver and saves it to the database.
     * @async
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
     */
	createDriver: async function (req, res) {
        try{
            let aDriver = new Driver ({
                driverName:req.body.name, 
                driverDepartment:req.body.department, 
                driverLicense:req.body.license, 
                driverIsActive: req.body.isActive == '1' })
            await aDriver.save(); // save the new driver to the database
            getCounters().insert += 1 //increment the insert counter
            saveData() //save the counter data 
            res.redirect("/33520496/Yang/drivers"); //redirect to drivers list
        } catch (err){
            res.render("invalid-data.ejs"); //render invalid data page if there exist any error
        }
	},

    /**
     * Handler method that lists all drivers 
     * @async     
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
     */
	listDriver: async function (req, res) {
        if(state.loggedIn == true){
            getCounters().retrieve += 1 // increment the retrieve counter
            saveData() // save the counter data
            let data = await Driver.find({}); // Fetch all drivers from the database
            res.render("view-driver.ejs",{records: data});} // Render the view with the driver data
        else{
            res.redirect("/33520496/Yang/users/login"); // redirect to login page if not logged in 
        }
	},

    /**
     * Handler method to display the page to list drivers by department
     * @async     
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
     */
    listByDepartmentPage: function (req, res) {
        if(state.loggedIn == true){
            res.render("list-driver-dep.ejs");}
        else{
            res.redirect("/33520496/Yang/users/login");
        }
	},

    /**
     * Handler method that lists drivers by department
     * @async     
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
     */
    listByDepartment: async function (req, res) {
        let data = await Driver.find({driverDepartment:req.body.department}); // fetch drivers by department
        getCounters().retrieve += 1 // increment the retrieve counter
        saveData() // save the counter data
        res.render("view-driver.ejs",{records: data}); 
	},

    /**
     * Handler method to display the page to delete a driver
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
     */
    deleteDriverPage: function (req, res) {
        if(state.loggedIn == true){
            res.render("delete-driver.ejs");}
        else{
            res.redirect("/33520496/Yang/users/login");
        }
	},

    /**
     * Handler method to delete driver based on the driverID via query string 
     * @async
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
     */
    deleteDriver: async function (req, res) {
		let id = req.query.driverId;
        let delOperation = await Driver.deleteOne({driverId: id});
        if (delOperation.deletedCount == 0){
            res.render("invalid-data.ejs");
        }else{
            getCounters().delete += 1 // increment the delete counter
            saveData() // save the counter data
            res.redirect("/33520496/Yang/drivers");
        }

	}
};
