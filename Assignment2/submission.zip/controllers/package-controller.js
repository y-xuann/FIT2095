const Driver = require("../models/driver");
const Package = require("../models/package");
const {getCounters, saveData} = require("./counter")
let state = require("../models/login-state")

module.exports = {
    /** 
     * Handler method to display the page to add a new package
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
    */
	createPackagesPage: async function (req, res) {
        if(state.loggedIn == true){
            let data = await Driver.find({});
            res.render("add-packages.ejs", {records: data});
        }else{
            res.redirect("/33520496/Yang/users/login");
        }
	},

    /**
     * Handler method which creates a new package and saves it to the database.
     * @async
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
     */
	createPackages: async function (req, res) {
        try{
            //create new package
            let aPackage = new Package ({
                packageTitle:req.body.title, 
                packageWeight:req.body.weight,
                packageDestination: req.body.destination, 
                description: req.body.description, 
                isAllocated: req.body.isAllocated == '1' ,
                driverId: req.body.driverID
            })

            //from the driver id retrieve the mongodbid
            let drivers = await Driver.find()
            for (let i =0; i<drivers.length; i++){
                if (drivers[i].driverId == req.body.driverID){
                    drivers[i].assignedPackages.push(aPackage._id) //push mongodb id into assignedPackages
                    await drivers[i].save(); 
                    break
                }
            }
            await aPackage.save(); // save the new package to the database
            getCounters().insert += 1 //increment the insert counter
            saveData() //save the counter data 
            res.redirect("/33520496/Yang/packages");
        } catch (err){
            res.render("invalid-data.ejs");
        }
	},

    /**
     * Handler method that lists all packages
     * @async     
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
     */
	listPackages: async function (req, res) {
        if(state.loggedIn == true){
            let data = await Package.find({});
            getCounters().retrieve += 1 // increment the retrieve counter
            saveData() // save the counter data
            res.render("view-packages.ejs",{records: data});
        }else{
            res.redirect("/33520496/Yang/users/login");
        }
	},

    /**
     * Handler method to display the page to delete a package
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
     */
    deletePackagesPage: function (req, res) {
        if(state.loggedIn == true){
            res.render("delete-packages.ejs");
        }else{
            res.redirect("/33520496/Yang/users/login");
        }
	},

    /**
     * Handler method to delete packages based on the packageID via query string 
     * @async
     * @function
     * @param {string} path - Express path
     * @param {function} callback - asynchronous callback function
     */
    deletePackages: async function (req, res) {
        // delete the package 
        let delOperation = await Package.deleteOne({packageId: req.query.packageId});
        if (delOperation.deletedCount == 0){
            res.render("invalid-data.ejs");
        }else{
            getCounters().delete += 1 // increment the delete counter
            saveData() // save the counter data
            res.redirect("/33520496/Yang/packages");
        }
	}
};

