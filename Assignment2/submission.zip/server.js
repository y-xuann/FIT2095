const mongoose = require("mongoose");
const express = require("express");

//Import route modules 
const driverRouter = require("./routes/driver-routes");
const packageRouter = require("./routes/package-routes");
const userRouter = require("./routes/user-routes");

//Import API route modules
const driverAPIRouter = require("./routes/driver-api-routes");
const packageAPIRouter = require("./routes/package-api-routes");
const userAPIRouter = require("./routes/user-api-routes");

//Import models
const Driver = require("./models/driver");
const Package = require("./models/package");
let state = require("./models/login-state"); //login state module to check if the user is logged in 

// Firebase configuration
const db = require("./firebase-config")

const app = express();
app.listen(8080);

// Middleware to parse incoming JSON request
app.use(express.json());

// Serve static Bootstrap CSS and image files
app.use(express.static("node_modules/bootstrap/dist/css"));
app.use(express.static("images"));

// Set EJS as the templating engine and configure it
app.engine("ejs", require("ejs").renderFile);
app.set("view engine", "ejs");

// Middleware to parse URL-encoded bodies (used for forms)
app.use(express.urlencoded({ extended: true }));

const url = "mongodb://10.192.0.5:27017/a2";

// Async function to connect to MongoDB
async function connect(url) {
	await mongoose.connect(url);
	return "Connected Successfully";
}

// Define routes for drivers package and users
app.use("/33520496/Yang/drivers", driverRouter);
app.use("/33520496/Yang/packages", packageRouter);
app.use("/33520496/Yang/users", userRouter);

// Define API routes for drivers package and users
app.use("/33520496/Yang/api/v1/drivers", driverAPIRouter);
app.use("/33520496/Yang/api/v1/packages", packageAPIRouter);
app.use("/33520496/Yang/api/v1/users", userAPIRouter);

// Establish connection to MongoDB 
connect(url)
	.then(console.log)
	.catch((err) => console.log(err));


/**
 * Route for the home page
 * @name GET / 
 * @function
 * @param {string} path - Express path
 * @param {function} callback - asynchronous callback function
 * @description Fetches the number of drivers and packages from MongoDB and renders the home page
 */
app.get('/', async function (req, res) {
    const findDriver = await Driver.find();
    const findPackage= await Package.find();
    res.render("index.ejs", {
        numDriver:findDriver.length,
        numPackage: findPackage.length});
});

/**
 * Route for the stats page
 * @name GET /33520496/Yang/stats
 * @function
 * @param {string} path - Express path
 * @param {function} callback - asynchronous callback function
 * @description Displays user statistics from Firestore if the user is logged in, else redirects to login page
 */
app.get('/33520496/Yang/stats', async function (req, res) {
    if(state.loggedIn == true){
        data = (await db.collection('data').doc('stats').get()).data();
        res.render("stats.ejs", {records:data})
    }else{
        res.redirect("/33520496/Yang/users/login");
    }

});

/**
 * API route for stats
 * @name GET /33520496/Yang/api/v1/stats
 * @function
 * @param {string} path - Express path
 * @param {function} callback - asynchronous callback function
 * @description Returns user statistics in JSON format if logged in, otherwise returns a 401 status
 */
app.get('/33520496/Yang/api/v1/stats', async function (req, res) {
    if(state.loggedIn == true){
        data = (await db.collection('data').doc('stats').get()).data();
        res.status(200).json({data});
    }else{
        res.status(401).json({"status": 'Please log in.'});
    }

});

/**
 * Route to handle undefined routes (404 error)
 * @name GET /*
 * @param {string} path - Express path
 * @param {function} callback - Express callback
 * @description Renders an error page for any route that is not defined.
 */
app.get('/*', function (req, res) {
    res.render("404.ejs");
  });


