const express = require("express");
const packageCont = require("../controllers/package-controller");

const router = express.Router();

/**
 * Route to display the page for adding a new package.
 * @name GET /add-packages
 * @function
 * @description Call the handler method createPackagesPage()
 */
router.get("/add-packages", packageCont.createPackagesPage);

/**
 * Route to create a new package.
 * @name POST /add-driver
 * @function
 * @description Call the handler method createPackages()
 */
router.post("/add-packages", packageCont.createPackages);

/**
 * Route to display the list of all packages.
 * @name GET /
 * @function
 * @description Call the handler method listPackages()
 */
router.get("/", packageCont.listPackages);

/**
 * Route to display the page for deleting a package.
 * @name GET /delete-packages
 * @function
 * @description Call the handler method deletePackagesPage()
 */
router.get("/delete-packages", packageCont.deletePackagesPage);

/**
 * Route to handle package deletion via query string (e.g., ?id=driverId).
 * @name GET /delete-packages-req
 * @function
 * @description Call the handler method deletePackages()
 */
router.get("/delete-packages-req", packageCont.deletePackages);

module.exports = router;